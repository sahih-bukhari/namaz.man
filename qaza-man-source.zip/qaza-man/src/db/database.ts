import * as SQLite from 'expo-sqlite';
import { PRAYERS, PrayerDebtInput, PrayerKey, remainingCount } from '../domain/calculations';

export type DebtRow = { prayer: PrayerKey; base_count: number; adjustment: number; updated_at: string };
export type PrayerLog = {
  id: number;
  prayer: PrayerKey;
  quantity: number;
  occurred_on: string;
  created_at: string;
  note: string;
};
export type BackupPayload = {
  app: 'qaza-man';
  formatVersion: 1;
  exportedAt: string;
  debts: DebtRow[];
  logs: PrayerLog[];
  settings: Array<{ key: string; value: string }>;
};

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

async function openDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!databasePromise) {
    databasePromise = (async () => {
      const database = await SQLite.openDatabaseAsync('qaza-man.db');
      await database.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = FULL;
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS prayer_debts (
          prayer TEXT PRIMARY KEY NOT NULL,
          base_count INTEGER NOT NULL CHECK (base_count >= 0),
          adjustment INTEGER NOT NULL DEFAULT 0 CHECK (adjustment >= 0),
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS prayer_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          prayer TEXT NOT NULL CHECK (prayer IN ('fajr','dhuhr','asr','maghrib','isha')),
          quantity INTEGER NOT NULL CHECK (quantity > 0),
          occurred_on TEXT NOT NULL,
          created_at TEXT NOT NULL,
          note TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_prayer_logs_date ON prayer_logs(occurred_on DESC);
        CREATE TABLE IF NOT EXISTS app_settings (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT NOT NULL
        );
        PRAGMA user_version = 1;
      `);
      return database;
    })().catch((error) => {
      databasePromise = null;
      throw error;
    });
  }
  return databasePromise;
}

function isPrayerKey(value: unknown): value is PrayerKey {
  return PRAYERS.some((prayer) => prayer.key === value);
}

export async function initializeDatabase(): Promise<void> { await openDatabase(); }

export async function loadDebts(): Promise<DebtRow[]> {
  const database = await openDatabase();
  return database.getAllAsync<DebtRow>(
    "SELECT prayer, base_count, adjustment, updated_at FROM prayer_debts ORDER BY CASE prayer WHEN 'fajr' THEN 1 WHEN 'dhuhr' THEN 2 WHEN 'asr' THEN 3 WHEN 'maghrib' THEN 4 ELSE 5 END",
  );
}

export async function loadLogs(limit = 200): Promise<PrayerLog[]> {
  const database = await openDatabase();
  return database.getAllAsync<PrayerLog>(
    'SELECT id, prayer, quantity, occurred_on, created_at, note FROM prayer_logs ORDER BY occurred_on DESC, id DESC LIMIT ?', limit,
  );
}

export async function loadCompletedTotals(): Promise<Record<PrayerKey, number>> {
  const database = await openDatabase();
  const rows = await database.getAllAsync<{ prayer: PrayerKey; total: number | null }>(
    'SELECT prayer, SUM(quantity) AS total FROM prayer_logs GROUP BY prayer',
  );
  const totals: Record<PrayerKey, number> = { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };
  for (const row of rows) if (isPrayerKey(row.prayer)) totals[row.prayer] = row.total ?? 0;
  return totals;
}

function isValidIsoDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

export async function loadCompletedOnDate(isoDate: string): Promise<number> {
  const database = await openDatabase();
  const row = await database.getFirstAsync<{ total: number | null }>(
    'SELECT SUM(quantity) AS total FROM prayer_logs WHERE occurred_on = ?', isoDate,
  );
  return row?.total ?? 0;
}

export async function loadSetting(key: string, fallback: string): Promise<string> {
  const database = await openDatabase();
  const row = await database.getFirstAsync<{ value: string }>(
    'SELECT value FROM app_settings WHERE key = ?', key,
  );
  return row?.value ?? fallback;
}

export async function saveSetting(key: string, value: string): Promise<void> {
  const database = await openDatabase();
  await database.runAsync(
    'INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
    key, value,
  );
}

export async function saveDebtEntries(entries: PrayerDebtInput[]): Promise<void> {
  const database = await openDatabase();
  if (entries.length !== PRAYERS.length || new Set(entries.map((entry) => entry.prayer)).size !== PRAYERS.length) {
    throw new Error('برای هر پنج نماز باید دقیقاً یک مقدار محاسبه‌شده وجود داشته باشد.');
  }
  const now = new Date().toISOString();
  await database.withTransactionAsync(async () => {
    await database.runAsync('DELETE FROM prayer_debts');
    for (const entry of entries) {
      if (!isPrayerKey(entry.prayer) || !Number.isInteger(entry.baseCount) || entry.baseCount < 0 ||
          !Number.isInteger(entry.adjustment) || entry.adjustment < 0 || entry.adjustment > entry.baseCount) {
        throw new Error('اطلاعات محاسبه‌شده معتبر نیست.');
      }
      await database.runAsync(
        'INSERT INTO prayer_debts (prayer, base_count, adjustment, updated_at) VALUES (?, ?, ?, ?)',
        entry.prayer, entry.baseCount, entry.adjustment, now,
      );
    }
  });
}

export async function addPrayerLog(input: {
  prayer: PrayerKey; quantity: number; occurredOn: string; note?: string;
}): Promise<void> {
  const database = await openDatabase();
  if (!isPrayerKey(input.prayer)) throw new Error('نوع نماز معتبر نیست.');
  if (!Number.isInteger(input.quantity) || input.quantity < 1 || input.quantity > 10000) {
    throw new Error('تعداد باید عدد صحیح و بین ۱ تا ۱۰۰۰۰ باشد.');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.occurredOn)) throw new Error('تاریخ ثبت معتبر نیست.');

  await database.withTransactionAsync(async () => {
    const debt = await database.getFirstAsync<DebtRow>(
      'SELECT prayer, base_count, adjustment, updated_at FROM prayer_debts WHERE prayer = ?', input.prayer,
    );
    if (!debt) throw new Error('ابتدا مقدار نمازهای قضای خود را در بخش محاسبه ثبت کن.');
    const completed = await database.getFirstAsync<{ total: number | null }>(
      'SELECT SUM(quantity) AS total FROM prayer_logs WHERE prayer = ?', input.prayer,
    );
    const remaining = remainingCount(debt.base_count, debt.adjustment, completed?.total ?? 0);
    if (input.quantity > remaining) {
      throw new Error(`تعداد واردشده از باقی‌مانده بیشتر است. باقی‌مانده این نماز: ${remaining} عدد.`);
    }
    await database.runAsync(
      'INSERT INTO prayer_logs (prayer, quantity, occurred_on, created_at, note) VALUES (?, ?, ?, ?, ?)',
      input.prayer, input.quantity, input.occurredOn, new Date().toISOString(), input.note?.trim() ?? '',
    );
  });
}

export async function deletePrayerLog(id: number): Promise<void> {
  const database = await openDatabase();
  await database.runAsync('DELETE FROM prayer_logs WHERE id = ?', id);
}

export async function createBackupPayload(): Promise<BackupPayload> {
  const database = await openDatabase();
  const [debts, logs, settings] = await Promise.all([
    loadDebts(),
    loadLogs(100000),
    database.getAllAsync<{ key: string; value: string }>('SELECT key, value FROM app_settings ORDER BY key'),
  ]);
  return { app: 'qaza-man', formatVersion: 1, exportedAt: new Date().toISOString(), debts, logs, settings };
}

export function validateBackupPayload(value: unknown): asserts value is BackupPayload {
  if (!value || typeof value !== 'object') throw new Error('ساختار فایل پشتیبان معتبر نیست.');
  const payload = value as Partial<BackupPayload>;
  if (payload.app !== 'qaza-man' || payload.formatVersion !== 1 ||
      typeof payload.exportedAt !== 'string' || Number.isNaN(Date.parse(payload.exportedAt)) ||
      !Array.isArray(payload.debts) || !Array.isArray(payload.logs)) {
    throw new Error('این فایل پشتیبان مربوط به اپلیکیشن قضای من نیست یا نسخه آن پشتیبانی نمی‌شود.');
  }
  if (payload.debts.length > 5 || payload.logs.length > 100000 ||
      (payload.settings !== undefined && (!Array.isArray(payload.settings) || payload.settings.length > 100))) {
    throw new Error('حجم یا تعداد اطلاعات فایل پشتیبان غیرمجاز است.');
  }
  const debtKeys = new Set<string>();
  for (const debt of payload.debts) {
    if (!isPrayerKey(debt.prayer) || debtKeys.has(debt.prayer) ||
        !Number.isSafeInteger(debt.base_count) || debt.base_count < 0 ||
        !Number.isSafeInteger(debt.adjustment) || debt.adjustment < 0 || debt.adjustment > debt.base_count ||
        typeof debt.updated_at !== 'string') {
      throw new Error('اطلاعات بدهی نماز در فایل پشتیبان خراب یا نامعتبر است.');
    }
    debtKeys.add(debt.prayer);
  }
  const logIds = new Set<number>();
  for (const log of payload.logs) {
    if (!Number.isSafeInteger(log.id) || log.id < 1 || logIds.has(log.id) || !isPrayerKey(log.prayer) ||
        !Number.isSafeInteger(log.quantity) || log.quantity < 1 || !isValidIsoDate(log.occurred_on) ||
        typeof log.note !== 'string' || log.note.length > 120 || typeof log.created_at !== 'string') {
      throw new Error('یکی از ثبت‌های نماز در فایل پشتیبان معتبر نیست.');
    }
    logIds.add(log.id);
  }
  const settingKeys = new Set<string>();
  for (const setting of payload.settings ?? []) {
    if (!setting || typeof setting.key !== 'string' || setting.key.length < 1 || setting.key.length > 100 ||
        settingKeys.has(setting.key) || typeof setting.value !== 'string' || setting.value.length > 10000) {
      throw new Error('یکی از تنظیمات فایل پشتیبان معتبر نیست.');
    }
    settingKeys.add(setting.key);
  }
}

export async function restoreBackupPayload(payload: BackupPayload): Promise<void> {
  validateBackupPayload(payload);
  const database = await openDatabase();
  await database.withTransactionAsync(async () => {
    await database.runAsync('DELETE FROM prayer_logs');
    await database.runAsync('DELETE FROM prayer_debts');
    await database.runAsync('DELETE FROM app_settings');
    for (const debt of payload.debts) {
      await database.runAsync(
        'INSERT INTO prayer_debts (prayer, base_count, adjustment, updated_at) VALUES (?, ?, ?, ?)',
        debt.prayer, debt.base_count, debt.adjustment, debt.updated_at || new Date().toISOString(),
      );
    }
    for (const log of payload.logs) {
      await database.runAsync(
        'INSERT INTO prayer_logs (id, prayer, quantity, occurred_on, created_at, note) VALUES (?, ?, ?, ?, ?, ?)',
        log.id, log.prayer, log.quantity, log.occurred_on, log.created_at || new Date().toISOString(), log.note,
      );
    }
    for (const setting of payload.settings ?? []) {
      await database.runAsync('INSERT INTO app_settings (key, value) VALUES (?, ?)', setting.key, setting.value);
    }
  });
}

export async function eraseAllLocalData(): Promise<void> {
  const database = await openDatabase();
  await database.withTransactionAsync(async () => {
    await database.runAsync('DELETE FROM prayer_logs');
    await database.runAsync('DELETE FROM prayer_debts');
    await database.runAsync('DELETE FROM app_settings');
  });
}
