import { afghanDateToIso } from './calendar';

export const PRAYERS = [
  { key: 'fajr', name: 'صبح', rakats: 2 },
  { key: 'dhuhr', name: 'ظهر', rakats: 4 },
  { key: 'asr', name: 'عصر', rakats: 4 },
  { key: 'maghrib', name: 'مغرب', rakats: 3 },
  { key: 'isha', name: 'عشا', rakats: 4 },
] as const;

export type PrayerKey = (typeof PRAYERS)[number]['key'];
export type PrayerDebtInput = { prayer: PrayerKey; baseCount: number; adjustment: number };

export function inclusiveDayCount(startIso: string, endIso: string): number {
  const isoPattern = /^\d{4}-\d{2}-\d{2}$/;
  if (!isoPattern.test(startIso) || !isoPattern.test(endIso)) {
    throw new Error('فرمت تاریخ برای محاسبه معتبر نیست.');
  }
  const [sy, sm, sd] = startIso.split('-').map(Number);
  const [ey, em, ed] = endIso.split('-').map(Number);
  const startDate = new Date(Date.UTC(sy, sm - 1, sd));
  const endDate = new Date(Date.UTC(ey, em - 1, ed));
  const validStart = startDate.getUTCFullYear() === sy && startDate.getUTCMonth() === sm - 1 && startDate.getUTCDate() === sd;
  const validEnd = endDate.getUTCFullYear() === ey && endDate.getUTCMonth() === em - 1 && endDate.getUTCDate() === ed;
  if (!validStart || !validEnd) throw new Error('یکی از تاریخ‌ها در تقویم میلادی معادل معتبر ندارد.');
  const start = startDate.getTime();
  const end = endDate.getTime();
  if (start > end) throw new Error('تاریخ شروع نباید بعد از تاریخ پایان باشد.');
  const days = Math.floor((end - start) / 86_400_000) + 1;
  if (!Number.isSafeInteger(days) || days < 1) throw new Error('بازه انتخاب‌شده معتبر نیست.');
  return days;
}

export function calculateDebtFromAfghanDates(
  startDate: string,
  endDate: string,
  excludedDays: Partial<Record<PrayerKey, number>> = {},
): { days: number; entries: PrayerDebtInput[]; totalPrayers: number; totalRakats: number } {
  const startIso = afghanDateToIso(startDate);
  const endIso = afghanDateToIso(endDate);
  const days = inclusiveDayCount(startIso, endIso);
  const entries = PRAYERS.map(({ key, name }) => {
    const rawAdjustment = excludedDays[key] ?? 0;
    if (!Number.isInteger(rawAdjustment) || rawAdjustment < 0 || rawAdjustment > days) {
      throw new Error(`تعداد روزهای تعدیل‌شده برای نماز ${name} باید بین صفر و ${days} باشد.`);
    }
    return { prayer: key, baseCount: days, adjustment: rawAdjustment };
  });
  const totalPrayers = entries.reduce((sum, entry) => sum + entry.baseCount - entry.adjustment, 0);
  const totalRakats = entries.reduce((sum, entry) => {
    const prayer = PRAYERS.find((item) => item.key === entry.prayer)!;
    return sum + (entry.baseCount - entry.adjustment) * prayer.rakats;
  }, 0);
  return { days, entries, totalPrayers, totalRakats };
}

export function remainingCount(baseCount: number, adjustment: number, completedCount: number): number {
  return Math.max(0, baseCount - adjustment - completedCount);
}

export function totalRakatsRemaining(
  balances: Array<{ prayer: PrayerKey; remaining: number }>,
): number {
  return balances.reduce((sum, item) => {
    const prayer = PRAYERS.find((candidate) => candidate.key === item.prayer)!;
    return sum + item.remaining * prayer.rakats;
  }, 0);
}
