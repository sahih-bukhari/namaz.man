import { isValidJalaaliDate, toGregorian, toJalaali } from 'jalaali-js';

export const AFGHAN_MONTHS = [
  'حمل', 'ثور', 'جوزا', 'سرطان', 'اسد', 'سنبله',
  'میزان', 'عقرب', 'قوس', 'جدی', 'دلو', 'حوت',
] as const;

const EASTERN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';

export function toEnglishDigits(value: string): string {
  return value
    .replace(/[۰-۹]/g, (digit) => String(EASTERN_DIGITS.indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String(ARABIC_DIGITS.indexOf(digit)))
    .replace(/[٫٬]/g, (digit) => (digit === '٫' ? '.' : ','));
}

export function toPersianDigits(value: string | number): string {
  return String(value).replace(/[0-9]/g, (digit) => EASTERN_DIGITS[Number(digit)]);
}

export type AfghanDateParts = { year: number; month: number; day: number };

export function parseAfghanDate(value: string): AfghanDateParts {
  const normalized = toEnglishDigits(value.trim()).replace(/[.\-]/g, '/');
  const match = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(normalized);
  if (!match) {
    throw new Error('تاریخ را به شکل سال/ماه/روز وارد کن؛ مانند ۱۴۰۵/۰۱/۰۱.');
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (!isValidJalaaliDate(year, month, day)) {
    throw new Error('این تاریخ در تقویم هجری شمسی افغانستان معتبر نیست.');
  }
  return { year, month, day };
}

export function afghanDateToIso(value: string): string {
  const { year, month, day } = parseAfghanDate(value);
  const gregorian = toGregorian(year, month, day);
  return `${gregorian.gy}-${String(gregorian.gm).padStart(2, '0')}-${String(gregorian.gd).padStart(2, '0')}`;
}

export function isoToAfghanDate(isoDate: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoDate);
  if (!match) throw new Error('تاریخ ذخیره‌شده معتبر نیست.');
  const { jy, jm, jd } = toJalaali(Number(match[1]), Number(match[2]), Number(match[3]));
  return `${toPersianDigits(jy)}/${toPersianDigits(String(jm).padStart(2, '0'))}/${toPersianDigits(String(jd).padStart(2, '0'))}`;
}

export function formatAfghanLongDate(date = new Date()): string {
  const { jy, jm, jd } = toJalaali(date);
  return `${toPersianDigits(jd)} ${AFGHAN_MONTHS[jm - 1]} ${toPersianDigits(jy)}`;
}

export function todayAfghanInput(date = new Date()): string {
  const { jy, jm, jd } = toJalaali(date);
  return `${toPersianDigits(jy)}/${toPersianDigits(String(jm).padStart(2, '0'))}/${toPersianDigits(String(jd).padStart(2, '0'))}`;
}
