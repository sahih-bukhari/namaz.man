import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import {
  BackupPayload,
  createBackupPayload,
  restoreBackupPayload,
  validateBackupPayload,
} from '../db/database';

export async function exportLocalBackup(): Promise<void> {
  const payload = await createBackupPayload();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const cacheDirectory = FileSystem.cacheDirectory;
  if (!cacheDirectory) throw new Error('پوشه موقت برای ساخت پشتیبان در دسترس نیست.');
  const uri = `${cacheDirectory}qaza-man-backup-${stamp}.json`;
  await FileSystem.writeAsStringAsync(uri, JSON.stringify(payload, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (!(await Sharing.isAvailableAsync())) throw new Error('امکان اشتراک‌گذاری فایل در این دستگاه فعال نیست.');
  await Sharing.shareAsync(uri, {
    mimeType: 'application/json', dialogTitle: 'ذخیره پشتیبان قضای من', UTI: 'public.json',
  });
}

export async function importLocalBackup(): Promise<boolean> {
  const result = await DocumentPicker.getDocumentAsync({
    type: ['application/json', 'text/json', 'public.json'],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (result.canceled || !result.assets[0]) return false;
  const raw = await FileSystem.readAsStringAsync(result.assets[0].uri, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  let parsed: unknown;
  try { parsed = JSON.parse(raw); }
  catch { throw new Error('فایل انتخاب‌شده JSON معتبر نیست.'); }
  validateBackupPayload(parsed);

  // Save a private on-device snapshot before replacing the current records.
  const current = await createBackupPayload();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const documentDirectory = FileSystem.documentDirectory;
  if (!documentDirectory) throw new Error('فضای خصوصی برنامه برای نگهداری نسخه ایمنی در دسترس نیست.');
  const safetyUri = `${documentDirectory}qaza-man-before-restore-${stamp}.json`;
  await FileSystem.writeAsStringAsync(safetyUri, JSON.stringify(current, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });

  await restoreBackupPayload(parsed as BackupPayload);
  return true;
}
