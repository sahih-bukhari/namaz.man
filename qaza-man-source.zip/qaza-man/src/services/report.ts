import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { PRAYERS, PrayerKey } from '../domain/calculations';
import { formatAfghanLongDate, toPersianDigits } from '../domain/calendar';

export type ReportBalance = {
  prayer: PrayerKey;
  remaining: number;
  completed: number;
  target: number;
  rakats: number;
};

function safeNumber(value: number): string {
  return toPersianDigits(value.toLocaleString('en-US'));
}

export async function exportProgressPdf(input: {
  balances: ReportBalance[];
  totalTarget: number;
  totalDone: number;
  totalRemaining: number;
  rakatsRemaining: number;
  progress: number;
}): Promise<void> {
  const rows = input.balances.map((balance) => {
    const name = PRAYERS.find((prayer) => prayer.key === balance.prayer)?.name ?? '';
    return `<tr><td>${name}</td><td>${safeNumber(balance.target)}</td><td>${safeNumber(balance.completed)}</td><td>${safeNumber(balance.remaining)}</td><td>${safeNumber(balance.remaining * balance.rakats)}</td></tr>`;
  }).join('');

  const html = `<!DOCTYPE html>
  <html lang="fa" dir="rtl">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      * { box-sizing: border-box; }
      body { font-family: Tahoma, Arial, sans-serif; color: #20352F; padding: 28px; direction: rtl; }
      h1 { color: #075D4D; font-size: 25px; margin: 0 0 6px; }
      .sub { color: #78857F; font-size: 12px; margin-bottom: 24px; }
      .summary { background: #E5F1EC; border: 1px solid #D5E7DE; border-radius: 14px; padding: 18px; margin-bottom: 20px; }
      .big { color: #075D4D; font-size: 28px; font-weight: bold; }
      .small { color: #65756E; font-size: 11px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 14px; }
      th { background: #075D4D; color: white; font-weight: normal; }
      th, td { padding: 11px 8px; border: 1px solid #E9E4DA; text-align: center; }
      tr:nth-child(even) td { background: #F8F6F0; }
      .note { margin-top: 22px; padding: 12px; background: #FBF5E4; color: #80601D; border-radius: 10px; font-size: 10px; line-height: 1.9; }
      .footer { margin-top: 24px; color: #89948F; font-size: 9px; text-align: center; }
    </style>
  </head>
  <body>
    <h1>گزارش پیشرفت نمازهای قضا</h1>
    <div class="sub">اپلیکیشن قضای من · تاریخ گزارش: ${formatAfghanLongDate()}</div>
    <div class="summary">
      <div class="small">نمازهای باقی‌مانده</div>
      <div class="big">${safeNumber(input.totalRemaining)}</div>
      <div class="small">رکعت باقی‌مانده: ${safeNumber(input.rakatsRemaining)} · پیشرفت: ${safeNumber(input.progress)}٪</div>
      <div class="small">کل هدف ثبت‌شده: ${safeNumber(input.totalTarget)} · ثبت‌شده: ${safeNumber(input.totalDone)}</div>
    </div>
    <table>
      <thead><tr><th>نماز</th><th>مجموع</th><th>انجام‌شده</th><th>باقی‌مانده</th><th>رکعت باقی</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="note">این گزارش صرفاً بازتاب اطلاعات ثبت‌شده در برنامه است. محاسبه بر اساس تاریخ‌ها و تعدیل‌های انتخاب‌شده توسط کاربر انجام می‌شود و جایگزین راهنمایی فقهی نیست.</div>
    <div class="footer">فایل به‌صورت محلی ساخته شده است؛ اشتراک‌گذاری آن فقط با اقدام خود کاربر انجام می‌شود.</div>
  </body></html>`;

  const result = await Print.printToFileAsync({ html, width: 595, height: 842 });
  if (!(await Sharing.isAvailableAsync())) throw new Error('امکان اشتراک‌گذاری فایل PDF در این دستگاه فعال نیست.');
  await Sharing.shareAsync(result.uri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: 'گزارش قضای من' });
}
