import test from 'node:test';
import assert from 'node:assert/strict';
import { afghanDateToIso, parseAfghanDate, toEnglishDigits } from '../src/domain/calendar';
import { calculateDebtFromAfghanDates, inclusiveDayCount, remainingCount, totalRakatsRemaining } from '../src/domain/calculations';

test('Persian and Arabic digits normalize to ASCII', () => {
  assert.equal(toEnglishDigits('۱۴۰۵/۰۱/۰۹'), '1405/01/09');
  assert.equal(toEnglishDigits('١٤٠٥/٠١/٠٩'), '1405/01/09');
});

test('Afghan solar date is validated and converted', () => {
  assert.equal(afghanDateToIso('۱۴۰۵/۰۱/۰۱'), '2026-03-21');
  assert.throws(() => parseAfghanDate('۱۴۰۵/۱۳/۰۱'));
});

test('day range includes both start and end', () => {
  assert.equal(inclusiveDayCount('2026-03-21', '2026-03-21'), 1);
  assert.equal(inclusiveDayCount('2026-03-21', '2026-03-22'), 2);
  assert.throws(() => inclusiveDayCount('2026-03-22', '2026-03-21'));
  assert.throws(() => inclusiveDayCount('2026-02-31', '2026-03-01'));
});

test('five prayers and rakats are calculated independently', () => {
  const result = calculateDebtFromAfghanDates('1405/01/01', '1405/01/02');
  assert.equal(result.days, 2);
  assert.equal(result.totalPrayers, 10);
  assert.equal(result.totalRakats, 34);
});

test('manual adjustment is applied only to selected prayer', () => {
  const result = calculateDebtFromAfghanDates('1405/01/01', '1405/01/03', { fajr: 1 });
  assert.equal(result.entries.find((entry) => entry.prayer === 'fajr')?.baseCount, 3);
  assert.equal(result.entries.find((entry) => entry.prayer === 'fajr')?.adjustment, 1);
  assert.equal(result.totalPrayers, 14);
  assert.equal(result.totalRakats, 49);
});

test('remaining count never becomes negative', () => {
  assert.equal(remainingCount(10, 2, 3), 5);
  assert.equal(remainingCount(10, 2, 20), 0);
});

test('rakats remaining use the correct prayer multipliers', () => {
  assert.equal(totalRakatsRemaining([
    { prayer: 'fajr', remaining: 1 }, { prayer: 'dhuhr', remaining: 1 },
    { prayer: 'asr', remaining: 1 }, { prayer: 'maghrib', remaining: 1 },
    { prayer: 'isha', remaining: 1 },
  ]), 17);
});
