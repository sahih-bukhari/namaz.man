import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFonts } from '@expo-google-fonts/vazirmatn/useFonts';
import { Vazirmatn_400Regular } from '@expo-google-fonts/vazirmatn/400Regular';
import { Vazirmatn_500Medium } from '@expo-google-fonts/vazirmatn/500Medium';
import { Vazirmatn_700Bold } from '@expo-google-fonts/vazirmatn/700Bold';
import {
  addPrayerLog,
  DebtRow,
  deletePrayerLog,
  initializeDatabase,
  loadCompletedTotals,
  loadCompletedOnDate,
  loadSetting,
  saveSetting,
  loadDebts,
  loadLogs,
  PrayerLog,
  saveDebtEntries,
  eraseAllLocalData,
} from './src/db/database';
import {
  calculateDebtFromAfghanDates,
  PRAYERS,
  PrayerKey,
  remainingCount,
  totalRakatsRemaining,
} from './src/domain/calculations';
import { formatAfghanLongDate, isoToAfghanDate, todayAfghanInput, afghanDateToIso, toEnglishDigits, toPersianDigits } from './src/domain/calendar';
import { exportLocalBackup, importLocalBackup } from './src/services/backup';
import { exportProgressPdf } from './src/services/report';

const C = {
  emerald: '#087C62',
  emeraldDark: '#075D4D',
  emeraldSoft: '#E5F1EC',
  cream: '#F4EBDD',
  canvas: '#F8F6F0',
  gold: '#D5AA45',
  goldSoft: '#F8F0D8',
  ink: '#20352F',
  muted: '#7B8982',
  border: '#E9E4DA',
  white: '#FFFFFF',
  danger: '#B34F43',
  dangerSoft: '#F9EAE7',
};

type Tab = 'home' | 'calculate' | 'record' | 'plan' | 'history' | 'settings';
type Balance = { prayer: PrayerKey; name: string; rakats: number; target: number; completed: number; remaining: number };

const FONT = { regular: 'Vazirmatn_400Regular', medium: 'Vazirmatn_500Medium', bold: 'Vazirmatn_700Bold' };

function digits(value: number): string { return toPersianDigits(value.toLocaleString('en-US')); }
function safeNumber(value: string): number {
  const normalized = toEnglishDigits(value).replace(/,/g, '').trim();
  if (!normalized) return 0;
  const number = Number(normalized);
  return Number.isSafeInteger(number) ? number : NaN;
}

function AppText({ children, style, bold = false, medium = false, muted = false }: {
  children: React.ReactNode; style?: any; bold?: boolean; medium?: boolean; muted?: boolean;
}) {
  return <Text style={[{ fontFamily: bold ? FONT.bold : medium ? FONT.medium : FONT.regular, color: muted ? C.muted : C.ink, textAlign: 'right', writingDirection: 'rtl' }, style]}>{children}</Text>;
}

function Card({ children, style }: { children: React.ReactNode; style?: any }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return <View style={styles.sectionTitleWrap}><AppText bold style={styles.sectionTitle}>{title}</AppText>{subtitle ? <AppText muted style={styles.sectionSubtitle}>{subtitle}</AppText> : null}</View>;
}

function PrimaryButton({ title, onPress, disabled, loading, icon, tone = 'primary' }: {
  title: string; onPress: () => void; disabled?: boolean; loading?: boolean; icon?: keyof typeof Ionicons.glyphMap; tone?: 'primary' | 'light' | 'danger';
}) {
  const bg = tone === 'danger' ? C.dangerSoft : tone === 'light' ? C.emeraldSoft : C.emerald;
  const color = tone === 'danger' ? C.danger : tone === 'light' ? C.emeraldDark : C.white;
  return (
    <Pressable disabled={disabled || loading} onPress={onPress} style={({ pressed }) => [styles.primaryButton, { backgroundColor: bg, opacity: disabled ? 0.48 : pressed ? 0.82 : 1 }]}>
      {loading ? <ActivityIndicator size="small" color={color} /> : icon ? <Ionicons name={icon} size={18} color={color} /> : null}
      <Text style={{ fontFamily: FONT.bold, color, fontSize: 14 }}>{title}</Text>
    </Pressable>
  );
}

function Field({ label, value, onChangeText, placeholder, keyboardType = 'default', helper, maxLength }: {
  label: string; value: string; onChangeText: (value: string) => void; placeholder?: string; keyboardType?: 'default' | 'numeric'; helper?: string; maxLength?: number;
}) {
  return (
    <View style={styles.fieldWrap}>
      <AppText medium style={styles.fieldLabel}>{label}</AppText>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#A4ADA8"
        keyboardType={keyboardType === 'numeric' ? 'number-pad' : 'default'}
        maxLength={maxLength}
        style={styles.input}
        textAlign="right"
        selectionColor={C.emerald}
        autoCorrect={false}
      />
      {helper ? <AppText muted style={styles.helper}>{helper}</AppText> : null}
    </View>
  );
}

function EmptyState({ icon, title, detail }: { icon: keyof typeof Ionicons.glyphMap; title: string; detail: string }) {
  return (
    <View style={styles.emptyState}>
      <View style={styles.emptyIcon}><Ionicons name={icon} size={27} color={C.emerald} /></View>
      <AppText bold style={{ fontSize: 16, marginTop: 13 }}>{title}</AppText>
      <AppText muted style={{ fontSize: 12, marginTop: 5, lineHeight: 22, textAlign: 'center' }}>{detail}</AppText>
    </View>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({
    Vazirmatn_400Regular,
    Vazirmatn_500Medium,
    Vazirmatn_700Bold,
  });
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errorText, setErrorText] = useState('');
  const [tab, setTab] = useState<Tab>('home');
  const [debts, setDebts] = useState<DebtRow[]>([]);
  const [logs, setLogs] = useState<PrayerLog[]>([]);
  const [completed, setCompleted] = useState<Record<PrayerKey, number>>({ fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 });
  const [todayCompleted, setTodayCompleted] = useState(0);
  const [dailyGoal, setDailyGoal] = useState('۵');

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState(todayAfghanInput());
  const [adjustments, setAdjustments] = useState<Record<PrayerKey, string>>({ fajr: '۰', dhuhr: '۰', asr: '۰', maghrib: '۰', isha: '۰' });
  const [preview, setPreview] = useState<ReturnType<typeof calculateDebtFromAfghanDates> | null>(null);

  const [selectedPrayer, setSelectedPrayer] = useState<PrayerKey>('fajr');
  const [quantity, setQuantity] = useState('۱');
  const [recordDate, setRecordDate] = useState(todayAfghanInput());
  const [note, setNote] = useState('');

  const refresh = useCallback(async () => {
    const todayIso = afghanDateToIso(todayAfghanInput());
    const [nextDebts, nextLogs, nextCompleted, nextToday, savedGoal] = await Promise.all([
      loadDebts(), loadLogs(150), loadCompletedTotals(), loadCompletedOnDate(todayIso), loadSetting('daily_goal', '5'),
    ]);
    setDebts(nextDebts);
    setLogs(nextLogs);
    setCompleted(nextCompleted);
    setTodayCompleted(nextToday);
    const goalNumber = Number(toEnglishDigits(savedGoal));
    setDailyGoal(Number.isSafeInteger(goalNumber) && goalNumber > 0 && goalNumber <= 1000 ? toPersianDigits(goalNumber) : '۵');
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        await initializeDatabase();
        await refresh();
        if (active) setReady(true);
      } catch (error) {
        if (active) setErrorText(error instanceof Error ? error.message : 'پایگاه‌داده محلی باز نشد.');
      }
    })();
    return () => { active = false; };
  }, [refresh]);

  const balances = useMemo<Balance[]>(() => PRAYERS.map((prayer) => {
    const row = debts.find((item) => item.prayer === prayer.key);
    const target = row ? Math.max(0, row.base_count - row.adjustment) : 0;
    const done = completed[prayer.key] ?? 0;
    return { prayer: prayer.key, name: prayer.name, rakats: prayer.rakats, target, completed: done, remaining: remainingCount(row?.base_count ?? 0, row?.adjustment ?? 0, done) };
  }), [debts, completed]);
  const totalTarget = balances.reduce((sum, item) => sum + item.target, 0);
  const totalDone = balances.reduce((sum, item) => sum + item.completed, 0);
  const totalRemaining = balances.reduce((sum, item) => sum + item.remaining, 0);
  const rakatsRemaining = totalRakatsRemaining(balances.map((item) => ({ prayer: item.prayer, remaining: item.remaining })));
  const progress = totalTarget > 0 ? Math.min(100, Math.round((Math.min(totalDone, totalTarget) / totalTarget) * 100)) : 0;
  const dailyGoalNumber = Math.max(1, safeNumber(dailyGoal) || 5);
  const estimatedDays = totalRemaining > 0 ? Math.ceil(totalRemaining / dailyGoalNumber) : 0;

  const showError = (error: unknown) => Alert.alert('مشکل پیش آمد', error instanceof Error ? error.message : 'عملیات انجام نشد. دوباره تلاش کن.');
  const handleCalculate = () => {
    try {
      const excluded = Object.fromEntries(PRAYERS.map((prayer) => [prayer.key, safeNumber(adjustments[prayer.key])])) as Record<PrayerKey, number>;
      const result = calculateDebtFromAfghanDates(startDate, endDate, excluded);
      setPreview(result);
    } catch (error) { showError(error); }
  };

  const handleSaveCalculation = async () => {
    if (!preview) return;
    setBusy(true);
    try {
      await saveDebtEntries(preview.entries);
      await refresh();
      setPreview(null);
      Alert.alert('محاسبه ذخیره شد', 'مقدار جدید نمازهای قضا در حافظه داخلی گوشی ثبت شد. ثبت‌های قبلی نیز حفظ شدند.');
      setTab('home');
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  };

  const handleSaveDailyGoal = async () => {
    const goal = safeNumber(dailyGoal);
    if (!Number.isSafeInteger(goal) || goal < 1 || goal > 1000) {
      Alert.alert('هدف نامعتبر است', 'هدف روزانه باید عدد صحیحی بین ۱ تا ۱۰۰۰ نماز باشد.');
      return;
    }
    setBusy(true);
    try { await saveSetting('daily_goal', String(goal)); setDailyGoal(toPersianDigits(goal)); Alert.alert('ذخیره شد', 'هدف روزانه روی همین گوشی ذخیره شد.'); }
    catch (error) { showError(error); }
    finally { setBusy(false); }
  };

  const handleExportPdf = async () => {
    setBusy(true);
    try { await exportProgressPdf({
      balances: balances.map((item) => ({ prayer: item.prayer, remaining: item.remaining, completed: item.completed, target: item.target, rakats: item.rakats })),
      totalTarget, totalDone, totalRemaining, rakatsRemaining, progress,
    }); }
    catch (error) { showError(error); }
    finally { setBusy(false); }
  };

  const handleAddLog = async () => {
    setBusy(true);
    try {
      const isoDate = afghanDateToIso(recordDate);
      const count = safeNumber(quantity);
      if (!Number.isFinite(count) || count < 1) throw new Error('تعداد نماز باید حداقل ۱ باشد.');
      await addPrayerLog({ prayer: selectedPrayer, quantity: count, occurredOn: isoDate, note });
      await refresh();
      setQuantity('۱');
      setNote('');
      Alert.alert('ثبت شد', 'نماز قضا در تاریخچه ذخیره شد.');
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  };

  const handleDeleteLog = (id: number) => {
    Alert.alert('حذف این ثبت؟', 'این مورد از تاریخچه پاک می‌شود و تعداد باقی‌مانده دوباره محاسبه خواهد شد.', [
      { text: 'انصراف', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: async () => {
        try { await deletePrayerLog(id); await refresh(); }
        catch (error) { showError(error); }
      } },
    ]);
  };

  const handleExport = async () => {
    setBusy(true);
    try { await exportLocalBackup(); }
    catch (error) { showError(error); }
    finally { setBusy(false); }
  };

  const handleImport = async () => {
    Alert.alert('بازیابی پشتیبان', 'اطلاعات فعلی با فایل پشتیبان جایگزین می‌شود. پیش از جایگزینی، یک نسخه پشتیبان از اطلاعات فعلی داخل حافظه برنامه ساخته می‌شود. ادامه می‌دهی؟', [
      { text: 'انصراف', style: 'cancel' },
      { text: 'انتخاب فایل', onPress: async () => {
        setBusy(true);
        try {
          const restored = await importLocalBackup();
          if (restored) { await refresh(); Alert.alert('بازیابی شد', 'اطلاعات فایل پشتیبان با موفقیت وارد شد.'); }
        } catch (error) { showError(error); }
        finally { setBusy(false); }
      } },
    ]);
  };

  const handleErase = () => {
    Alert.alert('پاک‌کردن همه اطلاعات؟', 'این کار تمام محاسبه‌ها و تاریخچه را از گوشی پاک می‌کند و برگشت‌پذیر نیست. پیش از آن پشتیبان بگیر.', [
      { text: 'انصراف', style: 'cancel' },
      { text: 'ادامه', style: 'destructive', onPress: () => Alert.alert('تأیید نهایی', 'مطمئنی که می‌خواهی همه اطلاعات محلی پاک شود؟', [
        { text: 'نه', style: 'cancel' },
        { text: 'بله، پاک شود', style: 'destructive', onPress: async () => {
          setBusy(true);
          try { await eraseAllLocalData(); await refresh(); setTab('home'); }
          catch (error) { showError(error); }
          finally { setBusy(false); }
        } },
      ]) },
    ]);
  };

  if (!fontsLoaded || (!ready && !errorText)) {
    return <SafeAreaView style={styles.loading}><StatusBar barStyle="dark-content" backgroundColor={C.canvas} /><ActivityIndicator color={C.emerald} size="large" /><AppText muted style={{ marginTop: 12 }}>قضای من در حال آماده‌شدن است…</AppText></SafeAreaView>;
  }
  if (errorText) {
    return <SafeAreaView style={styles.loading}><AppText bold style={{ fontSize: 18 }}>پایگاه‌داده باز نشد</AppText><AppText muted style={{ marginTop: 8 }}>{errorText}</AppText><PrimaryButton title="تلاش دوباره" onPress={() => { setErrorText(''); setReady(false); initializeDatabase().then(refresh).then(() => setReady(true)).catch((error) => setErrorText(String(error))); }} /></SafeAreaView>;
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'left', 'right']}>
      <StatusBar barStyle="dark-content" backgroundColor={C.canvas} />
      <View style={styles.appHeader}>
        <View style={styles.brandMark}><Ionicons name="moon" color={C.gold} size={19} /></View>
        <View style={{ flex: 1 }}>
          <AppText bold style={styles.brandName}>قضای من</AppText>
          <AppText muted style={styles.brandDate}>{formatAfghanLongDate()}</AppText>
        </View>
        <View style={styles.offlineBadge}><View style={styles.onlineDot} /><AppText medium style={styles.offlineText}>ذخیره در گوشی</AppText></View>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView key={tab} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          {tab === 'home' ? (
            <>
              <View style={styles.greetingBlock}>
                <AppText bold style={styles.greeting}>آرام و پیوسته پیش برو</AppText>
                <AppText muted style={styles.greetingSub}>هر قدم کوچک، بخشی از مسیر توست.</AppText>
              </View>
              {totalTarget === 0 ? (
                <Card style={styles.welcomeCard}>
                  <View style={styles.welcomeSymbol}><Ionicons name="leaf-outline" size={30} color={C.gold} /></View>
                  <AppText bold style={{ fontSize: 19, marginTop: 14 }}>از همین‌جا شروع کن</AppText>
                  <AppText muted style={{ fontSize: 12, lineHeight: 23, marginTop: 6, textAlign: 'center' }}>مدت نمازهای قضا را وارد کن تا تعداد هر نماز و رکعت‌ها برایت محاسبه شود.</AppText>
                  <PrimaryButton title="محاسبه نمازهای قضا" icon="calculator-outline" onPress={() => setTab('calculate')} />
                </Card>
              ) : (
                <Card style={styles.heroCard}>
                  <View style={styles.heroTop}>
                    <AppText style={{ color: '#E6F2ED', fontSize: 12 }}>نمازهای باقی‌مانده</AppText>
                    <View style={styles.heroPill}><Ionicons name="sparkles-outline" color={C.gold} size={13} /><Text style={styles.heroPillText}>قدم به قدم</Text></View>
                  </View>
                  <View style={styles.heroNumberRow}>
                    <AppText bold style={styles.heroNumber}>{digits(totalRemaining)}</AppText>
                    <AppText style={{ color: '#DBEDE6', marginBottom: 9 }}>نماز</AppText>
                  </View>
                  <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progress}%` }]} /></View>
                  <View style={styles.heroBottom}><AppText style={styles.heroSmall}>انجام‌شده: {digits(Math.min(totalDone, totalTarget))}</AppText><AppText style={styles.heroSmall}>پیشرفت: {digits(progress)}٪</AppText></View>
                  <View style={styles.heroDivider} />
                  <View style={styles.heroStats}>
                    <View style={styles.heroStat}><AppText style={styles.heroStatLabel}>رکعت باقی‌مانده</AppText><AppText bold style={styles.heroStatValue}>{digits(rakatsRemaining)}</AppText></View>
                    <View style={styles.heroStatSeparator} />
                    <View style={styles.heroStat}><AppText style={styles.heroStatLabel}>نماز ثبت‌شده</AppText><AppText bold style={styles.heroStatValue}>{digits(totalDone)}</AppText></View>
                  </View>
                </Card>
              )}

              <SectionTitle title="وضعیت هر نماز" subtitle="مقدار باقی‌مانده به تفکیک نماز" />
              <View style={styles.balanceList}>
                {balances.map((item) => (
                  <Card key={item.prayer} style={styles.balanceCard}>
                    <View style={styles.balanceHead}>
                      <View style={styles.prayerIcon}><Ionicons name="moon-outline" size={16} color={C.emerald} /></View>
                      <AppText bold style={{ flex: 1, fontSize: 14 }}>{item.name}</AppText>
                      <AppText bold style={{ color: C.emerald, fontSize: 15 }}>{digits(item.remaining)}</AppText>
                      <AppText muted style={{ fontSize: 11 }}>باقی</AppText>
                    </View>
                    <View style={styles.miniTrack}><View style={[styles.miniFill, { width: `${item.target > 0 ? Math.min(100, (Math.min(item.completed, item.target) / item.target) * 100) : 0}%` }]} /></View>
                    <View style={styles.balanceFoot}><AppText muted style={{ fontSize: 10 }}>انجام‌شده: {digits(item.completed)}</AppText><AppText muted style={{ fontSize: 10 }}>کل: {digits(item.target)}</AppText></View>
                  </Card>
                ))}
              </View>
              {totalTarget > 0 ? <Card style={styles.planPreview}>
                <View style={styles.planPreviewHead}><Ionicons name="calendar-outline" color={C.emerald} size={19} /><AppText bold style={{ flex: 1, fontSize: 13 }}>برنامه روزانه</AppText><AppText bold style={{ color: C.emerald }}>{digits(dailyGoalNumber)} نماز</AppText></View>
                <AppText muted style={{ fontSize: 11 }}>امروز ثبت کرده‌ای: {digits(todayCompleted)} از {digits(dailyGoalNumber)}</AppText>
                <View style={styles.miniTrack}><View style={[styles.miniFill, { width: `${Math.min(100, dailyGoalNumber > 0 ? (todayCompleted / dailyGoalNumber) * 100 : 0)}%` }]} /></View>
                <AppText muted style={{ fontSize: 10 }}>با این هدف، برآورد تکمیل باقی‌مانده: {digits(estimatedDays)} روز</AppText>
                <Pressable onPress={() => setTab('plan')} style={styles.linkRow}><AppText medium style={{ color: C.emerald, fontSize: 11 }}>تنظیم برنامه</AppText><Ionicons name="arrow-back" size={14} color={C.emerald} /></Pressable>
              </Card> : null}
              <PrimaryButton title="ثبت نماز قضا شده" icon="add-circle-outline" onPress={() => setTab('record')} />
            </>
          ) : null}

          {tab === 'calculate' ? (
            <>
              <SectionTitle title="محاسبه نمازهای قضا" subtitle="پنج نماز فرض را بر اساس تقویم هجری شمسی افغانستان می‌شمارد؛ روز شروع و پایان هر دو حساب می‌شوند." />
              <Card>
                <View style={styles.infoStrip}><Ionicons name="calendar-outline" size={17} color={C.emerald} /><AppText style={styles.infoText}>نمونه تاریخ: ۱۴۰۵/۰۱/۰۱ (سال/ماه/روز)</AppText></View>
                <Field label="تاریخ شروع" value={startDate} onChangeText={(v) => { setStartDate(v); setPreview(null); }} placeholder="۱۴۰۰/۰۱/۰۱" helper="از چه تاریخی نماز قضا آغاز شده است؟" />
                <Field label="تاریخ پایان" value={endDate} onChangeText={(v) => { setEndDate(v); setPreview(null); }} placeholder={todayAfghanInput()} helper="آخرین روزی که می‌خواهی در محاسبه شامل شود." />
                <View style={styles.adjustmentIntro}><AppText bold style={{ fontSize: 14 }}>تعدیل روزها (اختیاری)</AppText><AppText muted style={{ fontSize: 11, lineHeight: 19 }}>برای هر نماز، تعداد روزهایی را که بر اساس راهنمایی فقهی معتبر نباید در محاسبه بیاید وارد کن. برنامه خودش حکم فقهی صادر نمی‌کند و نماز وتر را در این نسخه جداگانه محاسبه نمی‌کند.</AppText></View>
                {PRAYERS.map((prayer) => (
                  <View key={prayer.key} style={styles.adjustmentRow}>
                    <AppText medium style={{ flex: 1, fontSize: 13 }}>{prayer.name}</AppText>
                    <View style={styles.adjustmentInputWrap}><TextInput value={adjustments[prayer.key]} onChangeText={(v) => { setAdjustments((old) => ({ ...old, [prayer.key]: v })); setPreview(null); }} keyboardType="number-pad" style={styles.adjustmentInput} textAlign="center" /></View>
                    <AppText muted style={{ fontSize: 10 }}>روز</AppText>
                  </View>
                ))}
                <PrimaryButton title="محاسبه دقیق" onPress={handleCalculate} icon="calculator-outline" />
              </Card>
              {preview ? (
                <Card style={styles.previewCard}>
                  <AppText bold style={{ fontSize: 16 }}>نتیجه محاسبه</AppText>
                  <AppText muted style={{ fontSize: 11, marginTop: 4 }}>روزهای بازه انتخاب‌شده: {digits(preview.days)}</AppText>
                  <View style={styles.previewTotal}><AppText muted style={{ fontSize: 12 }}>مجموع نمازها</AppText><AppText bold style={{ color: C.emerald, fontSize: 27 }}>{digits(preview.totalPrayers)}</AppText></View>
                  <View style={styles.previewTotal}><AppText muted style={{ fontSize: 12 }}>مجموع رکعت‌ها</AppText><AppText bold style={{ color: C.emerald, fontSize: 27 }}>{digits(preview.totalRakats)}</AppText></View>
                  {preview.entries.map((entry) => {
                    const prayer = PRAYERS.find((item) => item.key === entry.prayer)!;
                    return <View key={entry.prayer} style={styles.previewLine}><AppText>{prayer.name}</AppText><AppText bold>{digits(entry.baseCount - entry.adjustment)} نماز · {digits((entry.baseCount - entry.adjustment) * prayer.rakats)} رکعت</AppText></View>;
                  })}
                  <AppText muted style={{ fontSize: 10, lineHeight: 19, marginTop: 10 }}>این نتیجه یک محاسبه عددی بر اساس تاریخ و تعدیل‌هایی است که وارد کردی؛ تعیین تکلیف فقهی روزهای قضا با مرجع یا عالم مورد اعتماد است.</AppText>
                  <PrimaryButton title="ذخیره این محاسبه در گوشی" icon="save-outline" onPress={handleSaveCalculation} loading={busy} />
                </Card>
              ) : null}
            </>
          ) : null}

          {tab === 'record' ? (
            <>
              <SectionTitle title="ثبت نماز قضا شده" subtitle="هر بار که نماز قضایی را به‌جا آوردی، اینجا ثبت کن." />
              {totalTarget === 0 ? <Card><EmptyState icon="calculator-outline" title="اول باید محاسبه انجام شود" detail="ابتدا مقدار نمازهای قضا را در بخش محاسبه ذخیره کن." /><PrimaryButton title="رفتن به محاسبه" onPress={() => setTab('calculate')} /></Card> : (
                <Card>
                  <AppText medium style={styles.fieldLabel}>انتخاب نماز</AppText>
                  <View style={styles.prayerChoices}>{PRAYERS.map((prayer) => (
                    <Pressable key={prayer.key} onPress={() => setSelectedPrayer(prayer.key)} style={[styles.prayerChoice, selectedPrayer === prayer.key && styles.prayerChoiceActive]}>
                      <AppText medium style={{ color: selectedPrayer === prayer.key ? C.white : C.ink, fontSize: 12 }}>{prayer.name}</AppText>
                    </Pressable>
                  ))}</View>
                  <AppText muted style={{ fontSize: 11, marginTop: -3, marginBottom: 16 }}>باقی‌مانده نماز {PRAYERS.find((p) => p.key === selectedPrayer)?.name}: {digits(balances.find((b) => b.prayer === selectedPrayer)?.remaining ?? 0)}</AppText>
                  <Field label="تعداد نمازهایی که ثبت می‌کنی" value={quantity} onChangeText={setQuantity} keyboardType="numeric" placeholder="۱" />
                  <Field label="تاریخ انجام نماز" value={recordDate} onChangeText={setRecordDate} placeholder={todayAfghanInput()} helper="تاریخ به تقویم هجری شمسی افغانستان." />
                  <Field label="یادداشت (اختیاری)" value={note} onChangeText={setNote} placeholder="یادداشت کوتاه" maxLength={120} />
                  <PrimaryButton title="ذخیره ثبت" icon="checkmark-circle-outline" onPress={handleAddLog} loading={busy} />
                </Card>
              )}
              <Card style={styles.tipCard}><Ionicons name="shield-checkmark-outline" size={20} color={C.emerald} /><View style={{ flex: 1 }}><AppText bold style={{ fontSize: 13 }}>ثبت امن و دقیق</AppText><AppText muted style={{ fontSize: 11, lineHeight: 19, marginTop: 3 }}>برنامه اجازه نمی‌دهد تعداد ثبت‌شده از باقی‌مانده بیشتر شود. می‌توانی ثبت اشتباه را از تاریخچه حذف کنی.</AppText></View></Card>
            </>
          ) : null}

          {tab === 'plan' ? (
            <>
              <SectionTitle title="برنامه روزانه" subtitle="یک هدف واقع‌بینانه انتخاب کن و با آرامش ادامه بده." />
              <Card>
                <View style={styles.planHeroIcon}><Ionicons name="flag-outline" color={C.gold} size={25} /></View>
                <AppText bold style={{ fontSize: 17, marginTop: 4 }}>هدف روزانه تو</AppText>
                <AppText muted style={{ fontSize: 11, lineHeight: 20 }}>تعداد نمازهای قضایی که قصد داری در یک روز به‌جا بیاوری. این مقدار فقط برنامه شخصی توست و می‌توانی هر زمان تغییرش بدهی.</AppText>
                <View style={styles.goalQuickRow}>
                  {[1, 5, 10].map((value) => (
                    <Pressable key={value} onPress={() => setDailyGoal(toPersianDigits(value))} style={[styles.goalQuick, safeNumber(dailyGoal) === value && styles.goalQuickActive]}>
                      <AppText medium style={{ color: safeNumber(dailyGoal) === value ? C.white : C.ink }}>{digits(value)}</AppText>
                    </Pressable>
                  ))}
                </View>
                <Field label="هدف دلخواه (تعداد نماز در روز)" value={dailyGoal} onChangeText={setDailyGoal} keyboardType="numeric" placeholder="۵" helper="عدد بین ۱ تا ۱۰۰۰ وارد کن." />
                <PrimaryButton title="ذخیره هدف روزانه" icon="save-outline" onPress={handleSaveDailyGoal} loading={busy} />
              </Card>
              <Card>
                <AppText bold style={{ fontSize: 15 }}>برآورد مسیر</AppText>
                {totalTarget === 0 ? <AppText muted style={{ fontSize: 11, lineHeight: 21 }}>برای محاسبه زمان تقریبی، ابتدا تعداد نمازهای قضا را ثبت کن.</AppText> : <>
                  <View style={styles.planMetric}><AppText muted>نماز باقی‌مانده</AppText><AppText bold style={styles.planMetricValue}>{digits(totalRemaining)}</AppText></View>
                  <View style={styles.planMetric}><AppText muted>هدف روزانه</AppText><AppText bold style={styles.planMetricValue}>{digits(dailyGoalNumber)}</AppText></View>
                  <View style={styles.planMetric}><AppText muted>روزهای تخمینی تا پایان</AppText><AppText bold style={styles.planMetricValue}>{digits(estimatedDays)}</AppText></View>
                  <AppText muted style={{ fontSize: 10, lineHeight: 19, marginTop: 5 }}>این برآورد فرض می‌کند هر روز به اندازه هدف تعیین‌شده ثبت انجام شود؛ تعطیلی یا تغییر برنامه می‌تواند زمان واقعی را تغییر دهد.</AppText>
                </>}
              </Card>
              <Card>
                <AppText bold style={{ fontSize: 14 }}>عملکرد امروز · {formatAfghanLongDate()}</AppText>
                <View style={styles.todayGoalRow}><AppText bold style={{ color: C.emerald, fontSize: 22 }}>{digits(todayCompleted)}</AppText><AppText muted>از {digits(dailyGoalNumber)} نماز هدف روزانه</AppText></View>
                <View style={styles.progressTrackLight}><View style={[styles.progressFillLight, { width: `${Math.min(100, (todayCompleted / dailyGoalNumber) * 100)}%` }]} /></View>
              </Card>
            </>
          ) : null}

          {tab === 'history' ? (
            <>
              <SectionTitle title="تاریخچه ثبت‌ها" subtitle="آخرین ثبت‌های نماز قضا" />
              <PrimaryButton title="ساخت گزارش PDF" icon="document-text-outline" onPress={handleExportPdf} loading={busy} tone="light" />
              {logs.length === 0 ? <Card><EmptyState icon="time-outline" title="هنوز ثبتی وجود ندارد" detail="بعد از ثبت نمازهای قضا، تاریخچه آن‌ها در این صفحه نمایش داده می‌شود." /><PrimaryButton title="ثبت اولین نماز" onPress={() => setTab('record')} /></Card> : (
                <View style={{ gap: 9 }}>{logs.map((log) => {
                  const prayer = PRAYERS.find((item) => item.key === log.prayer)!;
                  return <Card key={log.id} style={styles.logCard}>
                    <View style={styles.logTop}><View style={styles.logIcon}><Ionicons name="checkmark" color={C.emerald} size={18} /></View><View style={{ flex: 1 }}><AppText bold style={{ fontSize: 14 }}>{prayer.name} · {digits(log.quantity)} نماز</AppText><AppText muted style={{ fontSize: 10, marginTop: 3 }}>{isoToAfghanDate(log.occurred_on)}</AppText></View><Pressable onPress={() => handleDeleteLog(log.id)} style={styles.deleteButton}><Ionicons name="trash-outline" color={C.danger} size={17} /></Pressable></View>
                    {log.note ? <AppText muted style={{ fontSize: 11, marginTop: 10 }}>{log.note}</AppText> : null}
                  </Card>;
                })}</View>
              )}
              {logs.length >= 150 ? <AppText muted style={{ textAlign: 'center', fontSize: 10, marginTop: 12 }}>۱۵۰ ثبت آخر نمایش داده می‌شود؛ همه ثبت‌ها در محاسبه و فایل پشتیبان محفوظ‌اند.</AppText> : null}
            </>
          ) : null}

          {tab === 'settings' ? (
            <>
              <SectionTitle title="تنظیمات و نگهداری اطلاعات" subtitle="اطلاعات تو روی همین دستگاه ذخیره می‌شود." />
              <Card style={styles.storageCard}>
                <View style={styles.storageIcon}><Ionicons name="phone-portrait-outline" size={22} color={C.emerald} /></View>
                <View style={{ flex: 1 }}><AppText bold style={{ fontSize: 14 }}>ذخیره‌سازی محلی فعال است</AppText><AppText muted style={{ fontSize: 11, lineHeight: 20, marginTop: 3 }}>بدون حساب کاربری و بدون ارسال اطلاعات به سرور. داده‌ها در پایگاه‌داده SQLite داخل برنامه نگهداری می‌شوند.</AppText></View>
              </Card>
              <Card>
                <AppText bold style={{ fontSize: 15, marginBottom: 6 }}>پشتیبان‌گیری و بازیابی</AppText>
                <AppText muted style={{ fontSize: 11, lineHeight: 20, marginBottom: 14 }}>فایل پشتیبان را در جای امنی مانند حافظه گوشی یا فضای ذخیره‌سازی شخصی خودت نگه دار تا هنگام تعویض گوشی بتوانی اطلاعات را برگردانی.</AppText>
                <PrimaryButton title="ساخت فایل پشتیبان" icon="download-outline" onPress={handleExport} loading={busy} />
                <View style={{ height: 9 }} />
                <PrimaryButton title="بازیابی از فایل پشتیبان" icon="refresh-circle-outline" onPress={handleImport} loading={busy} tone="light" />
              </Card>
              <Card style={styles.warningCard}>
                <Ionicons name="alert-circle-outline" size={21} color="#9A7425" />
                <View style={{ flex: 1 }}><AppText bold style={{ color: '#80601D', fontSize: 13 }}>نکته مهم درباره ماندگاری اطلاعات</AppText><AppText style={{ color: '#80601D', fontSize: 11, lineHeight: 20, marginTop: 4 }}>با بستن برنامه یا خاموش‌کردن گوشی اطلاعات پاک نمی‌شود. اما حذف برنامه، پاک‌کردن داده‌های آن، خرابی گوشی یا بازنشانی کارخانه می‌تواند اطلاعات محلی را از بین ببرد. برای همین مرتب فایل پشتیبان بگیر.</AppText></View>
              </Card>
              <Card>
                <AppText bold style={{ fontSize: 14, marginBottom: 5 }}>تقویم و زبان</AppText>
                <View style={styles.settingLine}><AppText muted>تقویم</AppText><AppText medium>هجری شمسی افغانستان</AppText></View>
                <View style={styles.settingLine}><AppText muted>نام ماه‌ها</AppText><AppText medium>حمل تا حوت</AppText></View>
                <View style={styles.settingLine}><AppText muted>زبان رابط</AppText><AppText medium>فارسی دری · راست‌چین</AppText></View>
                <View style={styles.settingLine}><AppText muted>پایگاه‌داده</AppText><AppText medium>SQLite روی دستگاه</AppText></View>
              </Card>
              <Card style={styles.eraseCard}>
                <AppText bold style={{ fontSize: 14, color: C.danger }}>پاک‌کردن اطلاعات این گوشی</AppText>
                <AppText muted style={{ fontSize: 11, lineHeight: 19, marginTop: 4, marginBottom: 12 }}>فقط زمانی استفاده کن که واقعاً می‌خواهی همه داده‌های محلی را پاک کنی.</AppText>
                <PrimaryButton title="پاک‌کردن همه اطلاعات" onPress={handleErase} tone="danger" icon="trash-outline" />
              </Card>
              <AppText muted style={{ fontSize: 10, textAlign: 'center', marginTop: 4 }}>قضای من · نسخه ۱.۰ · طراحی برای استفاده شخصی</AppText>
            </>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>

      <View style={styles.tabBar}>
        <TabButton label="خانه" icon="home-outline" active={tab === 'home'} onPress={() => setTab('home')} />
        <TabButton label="محاسبه" icon="calculator-outline" active={tab === 'calculate'} onPress={() => setTab('calculate')} />
        <TabButton label="ثبت" icon="add-circle-outline" active={tab === 'record'} onPress={() => setTab('record')} prominent />
        <TabButton label="برنامه" icon="calendar-outline" active={tab === 'plan'} onPress={() => setTab('plan')} />
        <TabButton label="تاریخچه" icon="time-outline" active={tab === 'history'} onPress={() => setTab('history')} />
        <TabButton label="تنظیمات" icon="settings-outline" active={tab === 'settings'} onPress={() => setTab('settings')} />
      </View>
    </SafeAreaView>
  );
}

function TabButton({ label, icon, active, onPress, prominent = false }: {
  label: string; icon: keyof typeof Ionicons.glyphMap; active: boolean; onPress: () => void; prominent?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={styles.tabButton}>
      <View style={[styles.tabIconWrap, prominent && styles.tabIconProminent, active && !prominent && styles.tabIconActive]}>
        <Ionicons name={icon} size={prominent ? 23 : 20} color={prominent ? C.white : active ? C.emerald : '#8C9892'} />
      </View>
      <Text style={{ fontFamily: active ? FONT.bold : FONT.regular, fontSize: 9, color: active ? C.emerald : '#8C9892', marginTop: 3 }}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: C.canvas },
  loading: { flex: 1, backgroundColor: C.canvas, justifyContent: 'center', alignItems: 'center', padding: 24 },
  appHeader: { paddingHorizontal: 18, paddingTop: 7, paddingBottom: 13, flexDirection: 'row-reverse', alignItems: 'center', gap: 10 },
  brandMark: { width: 39, height: 39, borderRadius: 14, backgroundColor: C.emeraldDark, alignItems: 'center', justifyContent: 'center' },
  brandName: { fontSize: 16, lineHeight: 22 },
  brandDate: { fontSize: 10, marginTop: 1 },
  offlineBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, backgroundColor: C.emeraldSoft, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6 },
  onlineDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: C.emerald },
  offlineText: { color: C.emeraldDark, fontSize: 9 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 6, paddingBottom: 26, gap: 13 },
  greetingBlock: { marginBottom: 1, paddingHorizontal: 2 },
  greeting: { fontSize: 19 },
  greetingSub: { fontSize: 11, marginTop: 2 },
  card: { backgroundColor: C.white, borderRadius: 19, padding: 16, borderWidth: 1, borderColor: C.border, gap: 9 },
  welcomeCard: { alignItems: 'center', paddingVertical: 24, paddingHorizontal: 22 },
  welcomeSymbol: { width: 62, height: 62, borderRadius: 22, backgroundColor: C.emeraldDark, alignItems: 'center', justifyContent: 'center' },
  heroCard: { backgroundColor: C.emeraldDark, borderColor: C.emeraldDark, padding: 19, gap: 0 },
  heroTop: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  heroPill: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4, backgroundColor: 'rgba(255,255,255,0.12)', paddingHorizontal: 8, paddingVertical: 5, borderRadius: 18 },
  heroPillText: { color: '#F7EAC7', fontFamily: FONT.medium, fontSize: 9 },
  heroNumberRow: { flexDirection: 'row-reverse', alignItems: 'flex-end', gap: 7, marginTop: 7, marginBottom: 13 },
  heroNumber: { color: C.white, fontSize: 43, lineHeight: 53 },
  progressTrack: { height: 7, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.18)', overflow: 'hidden' },
  progressFill: { height: 7, backgroundColor: C.gold, borderRadius: 8, alignSelf: 'flex-end' },
  heroBottom: { flexDirection: 'row-reverse', justifyContent: 'space-between', marginTop: 7 },
  heroSmall: { color: '#D7E8E1', fontSize: 10 },
  heroDivider: { height: 1, backgroundColor: 'rgba(255,255,255,0.17)', marginTop: 15, marginBottom: 12 },
  heroStats: { flexDirection: 'row-reverse', alignItems: 'center' },
  heroStat: { flex: 1, gap: 3 },
  heroStatLabel: { color: '#C5DDD3', fontSize: 10 },
  heroStatValue: { color: C.white, fontSize: 18 },
  heroStatSeparator: { width: 1, height: 32, backgroundColor: 'rgba(255,255,255,0.2)', marginHorizontal: 12 },
  sectionTitleWrap: { marginTop: 5, gap: 2 },
  sectionTitle: { fontSize: 16 },
  sectionSubtitle: { fontSize: 10 },
  balanceList: { gap: 8 },
  balanceCard: { paddingVertical: 11, paddingHorizontal: 13, gap: 7, borderRadius: 15 },
  balanceHead: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7 },
  prayerIcon: { width: 29, height: 29, borderRadius: 10, backgroundColor: C.emeraldSoft, alignItems: 'center', justifyContent: 'center' },
  miniTrack: { height: 4, backgroundColor: '#EDF0EB', borderRadius: 5, overflow: 'hidden' },
  miniFill: { height: 4, backgroundColor: C.gold, alignSelf: 'flex-end', borderRadius: 5 },
  balanceFoot: { flexDirection: 'row-reverse', justifyContent: 'space-between' },
  primaryButton: { minHeight: 47, borderRadius: 14, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 16, marginTop: 4 },
  infoStrip: { flexDirection: 'row-reverse', gap: 8, alignItems: 'center', backgroundColor: C.emeraldSoft, padding: 11, borderRadius: 12, marginBottom: 3 },
  infoText: { fontSize: 11, color: C.emeraldDark },
  fieldWrap: { gap: 5, marginBottom: 8 },
  fieldLabel: { fontSize: 12 },
  input: { borderWidth: 1, borderColor: C.border, backgroundColor: '#FDFCF9', minHeight: 47, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 9, fontFamily: FONT.regular, fontSize: 13, color: C.ink, writingDirection: 'rtl' },
  helper: { fontSize: 10, lineHeight: 17 },
  adjustmentIntro: { borderTopWidth: 1, borderTopColor: C.border, paddingTop: 14, marginTop: 5, gap: 3 },
  adjustmentRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9, paddingVertical: 4 },
  adjustmentInputWrap: { width: 68, height: 38, borderWidth: 1, borderColor: C.border, borderRadius: 10, backgroundColor: '#FDFCF9' },
  adjustmentInput: { flex: 1, padding: 0, fontFamily: FONT.medium, color: C.ink, fontSize: 13 },
  previewCard: { borderColor: '#D9E9E1', backgroundColor: '#FCFEFC' },
  previewTotal: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: C.border, paddingVertical: 6 },
  previewLine: { flexDirection: 'row-reverse', justifyContent: 'space-between', paddingVertical: 5 },
  emptyState: { alignItems: 'center', paddingVertical: 17, paddingHorizontal: 12 },
  emptyIcon: { width: 56, height: 56, borderRadius: 19, backgroundColor: C.emeraldSoft, alignItems: 'center', justifyContent: 'center' },
  prayerChoices: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 7, marginBottom: 10 },
  prayerChoice: { borderWidth: 1, borderColor: C.border, backgroundColor: C.canvas, paddingVertical: 9, paddingHorizontal: 15, borderRadius: 12 },
  prayerChoiceActive: { backgroundColor: C.emerald, borderColor: C.emerald },
  tipCard: { flexDirection: 'row-reverse', alignItems: 'flex-start', backgroundColor: C.emeraldSoft, borderColor: '#D5E7DE' },
  logCard: { padding: 13, gap: 0 },
  logTop: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10 },
  logIcon: { width: 35, height: 35, borderRadius: 12, backgroundColor: C.emeraldSoft, alignItems: 'center', justifyContent: 'center' },
  deleteButton: { width: 33, height: 33, borderRadius: 11, backgroundColor: C.dangerSoft, alignItems: 'center', justifyContent: 'center' },
  storageCard: { flexDirection: 'row-reverse', alignItems: 'center', backgroundColor: C.emeraldSoft, borderColor: '#D7E9E0' },
  storageIcon: { width: 45, height: 45, borderRadius: 15, backgroundColor: '#D3E8DE', alignItems: 'center', justifyContent: 'center' },
  warningCard: { flexDirection: 'row-reverse', alignItems: 'flex-start', backgroundColor: '#FBF5E4', borderColor: '#EEE1BC' },
  settingLine: { flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, borderTopColor: C.border, paddingVertical: 11 },
  eraseCard: { borderColor: '#F0DAD5' },
  planPreview: { borderColor: '#D7E9E0', backgroundColor: '#FCFEFC' },
  planPreviewHead: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8 },
  linkRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, alignSelf: 'flex-start', paddingVertical: 3 },
  planHeroIcon: { width: 52, height: 52, borderRadius: 18, backgroundColor: C.emeraldDark, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-start' },
  goalQuickRow: { flexDirection: 'row-reverse', gap: 8, marginVertical: 5 },
  goalQuick: { minWidth: 56, paddingHorizontal: 13, paddingVertical: 9, borderWidth: 1, borderColor: C.border, borderRadius: 11, alignItems: 'center', backgroundColor: C.canvas },
  goalQuickActive: { backgroundColor: C.emerald, borderColor: C.emerald },
  planMetric: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.border },
  planMetricValue: { color: C.emerald, fontSize: 17 },
  todayGoalRow: { flexDirection: 'row-reverse', alignItems: 'baseline', gap: 7, marginTop: 8 },
  progressTrackLight: { height: 8, borderRadius: 8, backgroundColor: '#E9EEE9', overflow: 'hidden', marginTop: 9 },
  progressFillLight: { height: 8, backgroundColor: C.gold, borderRadius: 8, alignSelf: 'flex-end' },
  tabBar: { flexDirection: 'row-reverse', backgroundColor: C.white, borderTopWidth: 1, borderTopColor: C.border, paddingTop: 7, paddingBottom: Platform.OS === 'ios' ? 5 : 8, paddingHorizontal: 5 },
  tabButton: { flex: 1, alignItems: 'center', justifyContent: 'center', minHeight: 49 },
  tabIconWrap: { width: 34, height: 29, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  tabIconActive: { backgroundColor: C.emeraldSoft },
  tabIconProminent: { width: 43, height: 36, borderRadius: 13, backgroundColor: C.emerald, marginTop: -13, shadowColor: C.emeraldDark, shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.2, shadowRadius: 5, elevation: 4 },
});
